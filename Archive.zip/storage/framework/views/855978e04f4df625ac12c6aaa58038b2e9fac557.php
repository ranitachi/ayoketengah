<?php $__env->startSection('title'); ?>
    Beranda Utama
<?php $__env->stopSection(); ?>
<?php $__env->startSection('konten'); ?>

    <?php echo $__env->make('front.content.home', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.front',['kontak'=>$kontak], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>