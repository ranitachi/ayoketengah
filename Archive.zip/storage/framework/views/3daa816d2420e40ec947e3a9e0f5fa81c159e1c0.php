<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>
        <?php echo $__env->yieldContent('title'); ?> | 
        Admin PPID Kabupaten Tangerang
    </title>

	<!-- Global stylesheets -->
	<?php echo $__env->make('backend.includes.link', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

</head>

<body>

	<?php echo $__env->make('backend.includes.navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


	<!-- Page container -->
	<div class="page-container">

		<!-- Page content -->
		<div class="page-content">

			<?php echo $__env->make('backend.includes.sidemenu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


			<!-- Main content -->
			<div class="content-wrapper">

				

                <?php echo $__env->yieldContent('header'); ?>
				<!-- Content area -->
				<div class="content">

					

					<?php echo $__env->yieldContent('konten'); ?>


					<?php echo $__env->make('backend.includes.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

				</div>
				<!-- /content area -->

			</div>
			<!-- /main content -->

		</div>
		<!-- /page content -->

	</div>
	<!-- /page container -->

</body>
</html>
<?php echo $__env->yieldContent('script'); ?>
<?php echo $__env->yieldContent('modal'); ?>
