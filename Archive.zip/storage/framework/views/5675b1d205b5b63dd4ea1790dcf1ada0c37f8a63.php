<!-- modernizr js -->
<script src="<?php echo e(asset('front/js/modernizr-2.8.3.min.js')); ?>"></script>
<!-- jquery latest version -->
<script src="<?php echo e(asset('front/js/jquery.min.js')); ?>"></script>
<!-- bootstrap js -->
<script src="<?php echo e(asset('front/js/bootstrap.min.js')); ?>"></script>
<!-- owl.carousel js -->
<script src="<?php echo e(asset('front/js/owl.carousel.min.js')); ?>"></script>
		<!-- slick.min js -->
<script src="<?php echo e(asset('front/js/slick.min.js')); ?>"></script>
<!-- isotope.pkgd.min js -->
<script src="<?php echo e(asset('front/js/isotope.pkgd.min.js')); ?>"></script>
<!-- imagesloaded.pkgd.min js -->
<script src="<?php echo e(asset('front/js/imagesloaded.pkgd.min.js')); ?>"></script>
<!-- wow js -->
<script src="<?php echo e(asset('front/js/wow.min.js')); ?>"></script>
<!-- counter top js -->
<script src="<?php echo e(asset('front/js/waypoints.min.js')); ?>"></script>
<script src="<?php echo e(asset('front/js/jquery.counterup.min.js')); ?>"></script>
<!-- magnific popup -->
<script src="<?php echo e(asset('front/js/jquery.magnific-popup.min.js')); ?>"></script>
<!-- rsmenu js -->
<script src="<?php echo e(asset('front/js/rsmenu-main.js')); ?>"></script>
<!-- plugins js -->
<script src="<?php echo e(asset('front/js/plugins.js')); ?>"></script>
		 <!-- main js -->
<script src="<?php echo e(asset('front/js/main.js')); ?>"></script>