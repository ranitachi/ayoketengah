<!DOCTYPE html>
<html lang="zxx">
    <head>
        <!-- meta tag -->
        <meta charset="utf-8">
        <title>
            <?php echo $__env->yieldContent('title'); ?> || AyoKeTengah
        </title>
        <?php echo $__env->make('front.includes.link', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </head>
    <body class="home1">
        <!--Preloader area start here-->
        
		<!--Preloader area end here-->
		
        <?php echo $__env->make('front.includes.header',['kontak'=>$kontak], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		
		<!-- Slider Area Start -->
        
        <!-- Slider Area End -->
		
		<?php echo $__env->yieldContent('konten'); ?>
        <!-- Footer Start -->
       <?php echo $__env->make('front.includes.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <!-- Footer End -->

        <!-- start scrollUp  -->
        <div id="scrollUp">
            <i class="fa fa-angle-up"></i>
        </div>
		
		<!-- Canvas Menu start -->
        <?php echo $__env->make('front.includes.menu-mini', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <!-- Canvas Menu end -->
        
        <!-- Search Modal Start -->
        <div aria-hidden="true" class="modal fade search-modal" role="dialog" tabindex="-1">
        	<button type="button" class="close" data-dismiss="modal" aria-label="Close">
	          <span aria-hidden="true" class="fa fa-close"></span>
	        </button>
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                    <div class="search-block clearfix">
                        <form>
                            <div class="form-group">
                                <input class="form-control" placeholder="eg: Computer Technology" type="text">
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <!-- Search Modal End --> 
        
        <?php echo $__env->make('front.includes.script', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </body>
</html>