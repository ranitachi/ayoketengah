<?php $__env->startSection('title'); ?>
    Data Kontak
<?php $__env->stopSection(); ?>
<?php $__env->startSection('header'); ?>
    <div class="page-header page-header-default">
		<div class="page-header-content">
			<div class="page-title">
				<h4><i class="icon-newspaper position-left"></i> <span class="text-semibold">Data</span> - Kontak</h4>
            </div>
            <div class="heading-elements">
				<a href="<?php echo e(route('admin-kontak',-1)); ?>" class="btn btn-sm ungu-bg text-white"><i class="icon-googleplus5"></i> &nbsp;<?php echo e($data ? 'Edit' :'Tambah'); ?> Kontak</a>
			</div>
		</div>
		
	</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('konten'); ?>
    <!-- Dashboard content -->
		<div class="row">
			<div class="col-lg-12">
				<div class="panel panel-flat">
                    <div class="panel-heading">
							<h5 class="panel-title">Data Kontak</h5>
							<div class="heading-elements">
								
					    	</div>
						</div>
                    <div class="panel-body">
                        <div class="row">
                            <div class="col-lg-12">
                                <?php if(Session::has('pesan')): ?>
                                    <div class="alert alert-success">
                                        <h4><i class="icon-checkmark"></i>&nbsp;<?php echo e(Session::get('pesan')); ?></h4>
                                    </div>
                                <?php endif; ?>
                                <?php if(Session::has('error')): ?>
                                    <div class="alert alert-danger">
                                        <h4><i class="icon-blocked"></i>&nbsp;<?php echo e(Session::get('error')); ?></h4>
                                    </div>
                                <?php endif; ?>
                                <?php if($data->count()!=0): ?>
                                    <form action="<?php echo e(route('admin-kontak.proses')); ?>" method="POST" class="form-horizontal" id="form-galeri">
                                        <?php echo csrf_field(); ?>
                                       
                                                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                                   
                                                    <div class="form-group">
                                                        <label class="col-lg-2 control-label text-right"><?php echo e($item->nama); ?> :</label>
                                                        <div class="col-lg-6">
                                                            <input type="hidden" name="nama[<?php echo e($item->id); ?>]" value="<?php echo e($item->nama); ?>">
                                                            <input type="text" name="value[<?php echo e($item->id); ?>]" id="value" class="form-control" placeholder="<?php echo e($item->nama); ?>" value="<?php echo e($item->value); ?>">
                                                        </div>
                                                    </div>    
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                                            
                                                
                                                <div class="text-right">
                                                    <button type="submit" id="simpan" class="btn btn-primary">Simpan <i class="icon-floppy-disk position-right"></i></button>
                                                </div>
                                            
                                    </form>
                                <?php else: ?>
                                    <div class="text-center">
                                        <h3>Data Kontak Masih Kosong</h3>
                                        <br>
                                        <a href="<?php echo e(route('admin-kontak')); ?>" class="btn btn-sm ungu-bg text-white"><i class="icon-googleplus5"></i> &nbsp;Tambah Kontak</a>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    
                    </div>
                </div>
		    </div>
		</div>
	<!-- /dashboard content -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script type="text/javascript" src="<?php echo e(asset('back/assets/js/pages/datatables_data_sources.js')); ?>"></script>
    <script>
         
        setTimeout(function(){
            $('.alert').fadeOut('');
        },3000);

        
        function hapus(id)
        {
            $('#modal_theme_primary').modal('show');
            $('#okhapus').one('click',function(){
                location.href=url+'/admin-kontak-hapus/'+id
            });
        }
    </script>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('modal'); ?>
    <div id="modal_theme_primary" class="modal fade in">
		<div class="modal-dialog">
			<div class="modal-content">
				<div class="modal-header bg-primary">
					<button type="button" class="close" data-dismiss="modal">×</button>
					<h6 class="modal-title">Informasi Hapus Data</h6>
				</div>
				<div class="modal-body">
					<h6 class="text-semibold">Apakah Anda Yakin ingin menghapus Data Kontak ini ?</h6>
				</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-link legitRipple" data-dismiss="modal">Close</button>
					<button type="button" id="okhapus" class="btn btn-primary legitRipple">Ya, Saya Yakin</button>
				</div>
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>