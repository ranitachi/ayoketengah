<?php $__env->startSection('title'); ?>
    Form <?php echo e($katg); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('header'); ?>
    <div class="page-header page-header-default">
		<div class="page-header-content">
			<div class="page-title">
                <h4><i class="icon-newspaper position-left"></i> <span class="text-semibold">Data <?php echo e($katg); ?></span> - Form</h4>
            </div>
            <div class="heading-elements">
				<a href="<?php echo e(url('tentang/'.$kat)); ?>" class="btn btn-sm ungu-bg text-white"><i class="icon-arrow-left12"></i> &nbsp;Kembali ke <?php echo e($katg); ?></a>
			</div>
		</div>
		
	</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('konten'); ?>
    <!-- Dashboard content -->
		<div class="row">
			<div class="col-lg-12">
                <?php if($errors->any()): ?>
                    <div class="alert alert-danger">
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>
                
                <form action="<?php echo e(url('tentang-proses/'.$kat)); ?>" method="POST" class="form-horizontal" id="form-galeri">
                    <?php echo csrf_field(); ?>
					<div class="panel panel-flat">
						<div class="panel-heading">
							<h5 class="panel-title">Form <?php echo e($katg); ?></h5>
							<div class="heading-elements">
								
					    	</div>
						</div>
						<div class="panel-body">
                            
							<div class="form-group">
								<label class="col-lg-2 control-label">Kategori :</label>
								<div class="col-lg-6">
                                    <input type="text" readonly name="kategori" id="kategori" class="form-control" placeholder="<?php echo e($katg); ?>" value="<?php echo e($id!=-1 ? $data->kategori : $katg); ?>">
								</div>
							</div>
							
							<div class="form-group">
								<label class="col-lg-12 control-label">Keterangan:</label>
								<div class="col-lg-12">
									<textarea rows="5" cols="5" name="isi" id="isi" class="isi form-control" placeholder="Enter your message here"><?php echo e($id!=-1 ? $data->isi : ''); ?>

                                    </textarea>
								</div>
							</div>
							<div class="text-right">
								<button type="button" id="simpan" class="btn btn-primary">Simpan <i class="icon-floppy-disk position-right"></i></button>
							</div>
						</div>
					</div>
				</form>
		    </div>
		</div>
	<!-- /dashboard content -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script type="text/javascript" src="<?php echo e(asset('back/assets/js/plugins/forms/selects/select2.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('back/assets/js/plugins/forms/styling/uniform.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('back/assets/js/pages/form_layouts.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('back/assets/js/plugins/notifications/pnotify.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('back/assets/js/plugins/notifications/noty.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('back/assets/js/plugins/notifications/jgrowl.min.js')); ?>"></script>

    
    
    <script src="<?php echo e(asset('vendor/unisharp/laravel-ckeditor/ckeditor.js')); ?>"></script>
    <script src="<?php echo e(asset('vendor/laravel-filemanager/js/lfm.js')); ?>"></script>
    
    <script>
        $('#simpan').on('click',function(){
            var kategori=$('#kategori_id').val();
            var isi=CKEDITOR.instances['isi'].getData();
            
            if(kategori=='')
            {
                notif('Anda Belum Menentukan <?php echo e($katg); ?> Gambar <?php echo e($katg); ?>');
            }
            else if(isi=='')
            {
                notif('Anda Belum Memasukan Keterangan <?php echo e($katg); ?>');
            }
            else
                $('#form-galeri').submit()
        });
        var domain = "<?php echo e(url('/laravel-filemanager')); ?>";
        var options = {
            filebrowserImageBrowseUrl: domain+'?type=Images',
            filebrowserImageUploadUrl: domain+'/upload?type=Images&_token=',
            filebrowserBrowseUrl: domain+'?type=Files',
            filebrowserUploadUrl: domain+'/upload?type=Files&_token=',
            height : 450
        };
        CKEDITOR.replace( 'isi' ,options);
        
        $('#lfm').filemanager('image', {prefix: domain});

        setTimeout(function(){
            $('.alert').hide('fadeOut');
        },3000);
    </script>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>