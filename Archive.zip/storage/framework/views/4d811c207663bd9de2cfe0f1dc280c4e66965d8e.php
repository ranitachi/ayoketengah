<?php $__env->startSection('title'); ?>
    About US
<?php $__env->stopSection(); ?>
<?php $__env->startSection('konten'); ?>

    <div class="rs-history sec-spacer">
        <div class="container">
            <div class="row">
                
                <div class="col-lg-12 col-md-12">
	                <div class="abt-title">
	                    <h2>ABOUT US</h2>
	                </div>
                	<div class="about-desc" style="text-align:justify !important;">
            			<?php if(isset($profil['about-us'])): ?>
							<?php echo $profil['about-us']->deskripsi; ?>

						<?php else: ?>
							<h1>Data Not Avaliable</h1>
						<?php endif; ?>
                	</div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.front',['kontak'=>$kontak], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>