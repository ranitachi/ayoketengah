@extends('layouts.front',['kontak'=>$kontak])
@section('title')
    Beranda Utama
@endsection
@section('konten')

    @include('front.content.home')

@endsection
