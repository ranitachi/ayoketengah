<!-- Footer -->
<div class="footer text-muted">
	&copy; {{date('Y')}}. <a href="#">Pejabat Pengelola Informasi dan Dokumentasi (PPID) Kabupaten Tangerang</a>
</div>
<!-- /footer -->